#include <stdio.h>

int main()
{
	printf("yockgen!! This is to demo DEBIAN packaging process!\n");
	return 0;
}
